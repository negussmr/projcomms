"""
utils.py
========
Shared helper utilities: FPS tracking, drawing routines for boxes/HUD,
a drop-oldest thread-safe frame queue, and small filesystem helpers.
"""

import os
import time
import queue
import datetime
from collections import deque

import cv2

import config


# ---------------------------------------------------------------------------
# Filesystem helpers
# ---------------------------------------------------------------------------
def ensure_dir(path: str) -> None:
    """Create a directory (and parents) if it does not already exist."""
    os.makedirs(path, exist_ok=True)


def generate_timestamp() -> str:
    """Return a filesystem-safe timestamp string, e.g. 2026-08-02_14-05-33."""
    return datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")


def generate_log_timestamp() -> str:
    """Return a human-readable timestamp for log lines."""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------------------
# FPS tracking
# ---------------------------------------------------------------------------
class FPSCounter:
    """Rolling-average FPS counter based on a sliding window of frame times."""

    def __init__(self, window_size: int = 30):
        self.window_size = window_size
        self._timestamps = deque(maxlen=window_size)

    def tick(self) -> float:
        """Call once per processed frame. Returns the current rolling FPS."""
        now = time.time()
        self._timestamps.append(now)
        if len(self._timestamps) < 2:
            return 0.0
        elapsed = self._timestamps[-1] - self._timestamps[0]
        if elapsed <= 0:
            return 0.0
        return (len(self._timestamps) - 1) / elapsed


# ---------------------------------------------------------------------------
# Frame queue with drop-oldest semantics (keeps latency low)
# ---------------------------------------------------------------------------
class FrameQueue:
    """
    A tiny wrapper around queue.Queue that always keeps only the most
    recent frame(s). When full, the oldest frame is discarded instead of
    blocking the producer thread. This keeps the detection loop working on
    fresh frames instead of falling behind the live stream.
    """

    def __init__(self, maxsize: int = 2):
        self._q = queue.Queue(maxsize=maxsize)

    def put(self, frame) -> None:
        if self._q.full():
            try:
                self._q.get_nowait()
            except queue.Empty:
                pass
        try:
            self._q.put_nowait(frame)
        except queue.Full:
            pass

    def get(self, timeout: float = 1.0):
        return self._q.get(timeout=timeout)

    def empty(self) -> bool:
        return self._q.empty()


# ---------------------------------------------------------------------------
# Drawing helpers
# ---------------------------------------------------------------------------
def draw_detection_box(frame, xyxy, class_name, confidence, color, obj_id=None):
    """
    Draw a single bounding box with an optional filled label onto `frame`.
    Respects config.SHOW_CLASS_NAME, config.SHOW_CONFIDENCE,
    config.SHOW_OBJECT_ID, config.DRAW_FILLED_LABEL, etc.
    """
    x1, y1, x2, y2 = [int(v) for v in xyxy]

    cv2.rectangle(frame, (x1, y1), (x2, y2), color, config.BOX_THICKNESS)

    if config.SHOW_OBJECT_CENTER:
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        cv2.circle(frame, (cx, cy), 3, color, -1)

    label_parts = []
    if config.SHOW_CLASS_NAME:
        label_parts.append(class_name)
    if config.SHOW_CONFIDENCE:
        label_parts.append(f"{confidence * 100:.1f}%")
    if config.SHOW_OBJECT_ID and obj_id is not None:
        label_parts.append(f"#{obj_id}")

    if not label_parts:
        return

    label = " ".join(label_parts)
    font = cv2.FONT_HERSHEY_SIMPLEX
    (text_w, text_h), baseline = cv2.getTextSize(
        label, font, config.FONT_SIZE, config.TEXT_THICKNESS
    )

    label_y1 = max(y1 - text_h - baseline - 4, 0)
    label_y2 = label_y1 + text_h + baseline + 4

    if config.DRAW_FILLED_LABEL:
        cv2.rectangle(frame, (x1, label_y1), (x1 + text_w + 6, label_y2), color, -1)
        text_color = (0, 0, 0)
    else:
        text_color = color

    cv2.putText(
        frame,
        label,
        (x1 + 3, label_y2 - baseline - 2),
        font,
        config.FONT_SIZE,
        text_color,
        config.TEXT_THICKNESS,
        cv2.LINE_AA,
    )


def draw_hud(frame, fps, detection_count, model_name, resolution, conf_threshold,
             recording=False, paused=False):
    """
    Draw a heads-up display bar across the top of the frame with FPS,
    detection count, model name, resolution, and confidence threshold.
    """
    h, w = frame.shape[:2]
    bar_height = 30
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, bar_height), (20, 20, 20), -1)
    cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.5
    thickness = 1
    color = (255, 255, 255)
    x = 8
    y = 20

    segments = []
    if config.SHOW_FPS:
        segments.append(f"FPS: {fps:.1f}")
    segments.append(f"Objects: {detection_count}")
    segments.append(f"Model: {model_name}")
    segments.append(f"Res: {resolution[0]}x{resolution[1]}")
    segments.append(f"Conf: {conf_threshold:.2f}")

    if recording:
        segments.append("REC")
    if paused:
        segments.append("PAUSED")

    text = "  |  ".join(segments)
    cv2.putText(frame, text, (x, y), font, scale, color, thickness, cv2.LINE_AA)

    if recording:
        cv2.circle(frame, (w - 18, 15), 6, (0, 0, 255), -1)


def resize_for_display(frame, target_width: int):
    """Resize a frame to `target_width` while preserving aspect ratio."""
    h, w = frame.shape[:2]
    if w == target_width:
        return frame
    scale = target_width / float(w)
    new_size = (target_width, int(h * scale))
    return cv2.resize(frame, new_size, interpolation=cv2.INTER_LINEAR)
