"""
logger.py
=========
Two responsibilities:
  1. setup_logger()      -> a standard Python logger that writes to both
                             the console and logs/app.log
  2. DetectionLogger      -> appends every detection event to
                             logs/detections.csv
"""

import os
import csv
import logging
from logging.handlers import RotatingFileHandler

import config
from utils import ensure_dir, generate_log_timestamp


def setup_logger(name: str = "esp32_yolo") -> logging.Logger:
    """Configure and return the application-wide logger."""
    ensure_dir(config.LOGS_DIR)
    log_path = os.path.join(config.LOGS_DIR, "app.log")

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    if logger.handlers:
        # Avoid duplicate handlers if setup_logger() is called more than once.
        return logger

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    file_handler = RotatingFileHandler(
        log_path, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger


class DetectionLogger:
    """
    Appends one CSV row per detected object to logs/detections.csv, with
    columns: timestamp, class_name, confidence, frame_number.
    """

    FIELDNAMES = ["timestamp", "class_name", "confidence", "frame_number"]

    def __init__(self, filename: str = "detections.csv"):
        ensure_dir(config.LOGS_DIR)
        self.csv_path = os.path.join(config.LOGS_DIR, filename)
        self._ensure_header()

    def _ensure_header(self) -> None:
        file_exists = os.path.isfile(self.csv_path)
        if not file_exists or os.path.getsize(self.csv_path) == 0:
            with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
                writer.writeheader()

    def log_detection(self, class_name: str, confidence: float, frame_number: int) -> None:
        """Append a single detection row to the CSV file."""
        if not config.SAVE_DETECTIONS:
            return
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=self.FIELDNAMES)
            writer.writerow(
                {
                    "timestamp": generate_log_timestamp(),
                    "class_name": class_name,
                    "confidence": f"{confidence * 100:.2f}%",
                    "frame_number": frame_number,
                }
            )
