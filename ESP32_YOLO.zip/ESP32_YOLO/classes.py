"""
classes.py
==========
Handles class name bookkeeping and deterministic color assignment so that
every class (whether it's a stock COCO class or a class from a custom
trained model like helmet.pt / fire.pt / attendance.pt) gets a consistent,
readable bounding-box color across the entire run.
"""

import hashlib


# Standard 80 COCO class names. Provided for reference / offline lookups.
# When a custom model is loaded, its own model.names dictionary is used
# instead -- this list is not required for the program to function.
COCO_CLASSES = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train",
    "truck", "boat", "traffic light", "fire hydrant", "stop sign",
    "parking meter", "bench", "bird", "cat", "dog", "horse", "sheep", "cow",
    "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
    "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard",
    "sports ball", "kite", "baseball bat", "baseball glove", "skateboard",
    "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork",
    "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair",
    "couch", "potted plant", "bed", "dining table", "toilet", "tv",
    "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave",
    "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase",
    "scissors", "teddy bear", "hair drier", "toothbrush",
]

# A handful of hand-picked colors (BGR, since OpenCV draws in BGR) for the
# most commonly detected classes. Anything not listed here falls back to a
# deterministic hash-based color so it never collides awkwardly and never
# changes between runs.
_PRESET_COLORS = {
    "person": (60, 220, 60),
    "car": (255, 140, 0),
    "truck": (255, 100, 0),
    "bus": (255, 80, 0),
    "motorcycle": (0, 165, 255),
    "bicycle": (0, 200, 255),
    "dog": (180, 105, 255),
    "cat": (200, 120, 255),
    "fire": (0, 0, 255),
    "helmet": (255, 255, 0),
    "no_helmet": (0, 0, 255),
    "smoke": (128, 128, 128),
}


def get_class_color(class_name: str) -> tuple:
    """
    Return a deterministic BGR color tuple for a given class name.

    Preset classes get a hand-tuned color. Any other class name (including
    ones from a completely custom model) gets a stable color derived from
    an MD5 hash of its name, so the same class always renders the same
    color across every run of the program.
    """
    key = class_name.lower().strip()
    if key in _PRESET_COLORS:
        return _PRESET_COLORS[key]

    digest = hashlib.md5(key.encode("utf-8")).hexdigest()
    r = int(digest[0:2], 16)
    g = int(digest[2:4], 16)
    b = int(digest[4:6], 16)

    # Keep colors reasonably bright/saturated so labels stay legible against
    # a typical video background.
    r = max(r, 60)
    g = max(g, 60)
    b = max(b, 60)

    return (b, g, r)  # BGR order for OpenCV


def build_color_map(model_names: dict) -> dict:
    """
    Build a {class_name: (b, g, r)} color map for every class a loaded
    YOLO model knows about. `model_names` is the `model.names` dict that
    Ultralytics YOLO models expose after loading.
    """
    return {name: get_class_color(name) for name in model_names.values()}
