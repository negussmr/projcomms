"""
recorder.py
===========
Handles saving the annotated video stream to disk as AVI or MP4, with
timestamped filenames and automatic folder creation.
"""

import os

import cv2

import config
from utils import ensure_dir, generate_timestamp


class VideoRecorder:
    """
    Wraps cv2.VideoWriter with start/stop/toggle semantics and automatic
    timestamped filenames written into config.RECORDINGS_DIR.
    """

    _FOURCC_MAP = {
        "mp4": "mp4v",
        "avi": "XVID",
    }

    def __init__(self, logger=None):
        self.logger = logger
        self._writer = None
        self._is_recording = False
        self._current_path = None
        self._frame_size = None

    @property
    def is_recording(self) -> bool:
        return self._is_recording

    def start(self, frame_width: int, frame_height: int) -> str:
        """Start a new recording. Returns the output file path."""
        if self._is_recording:
            return self._current_path

        ensure_dir(config.RECORDINGS_DIR)

        fmt = config.RECORDING_FORMAT.lower()
        if fmt not in self._FOURCC_MAP:
            fmt = "mp4"

        filename = f"recording_{generate_timestamp()}.{fmt}"
        path = os.path.join(config.RECORDINGS_DIR, filename)

        fourcc = cv2.VideoWriter_fourcc(*self._FOURCC_MAP[fmt])
        self._writer = cv2.VideoWriter(
            path, fourcc, config.RECORDING_FPS, (frame_width, frame_height)
        )

        if not self._writer.isOpened():
            if self.logger:
                self.logger.error(f"Failed to open video writer for {path}")
            self._writer = None
            return None

        self._current_path = path
        self._frame_size = (frame_width, frame_height)
        self._is_recording = True

        if self.logger:
            self.logger.info(f"Recording started: {path}")

        return path

    def write(self, frame) -> None:
        """Write a single annotated frame to the active recording, if any."""
        if not self._is_recording or self._writer is None:
            return

        h, w = frame.shape[:2]
        if (w, h) != self._frame_size:
            frame = cv2.resize(frame, self._frame_size)

        self._writer.write(frame)

    def stop(self) -> None:
        """Stop the active recording and release the writer."""
        if self._writer is not None:
            self._writer.release()
            if self.logger:
                self.logger.info(f"Recording stopped: {self._current_path}")
        self._writer = None
        self._is_recording = False
        self._current_path = None

    def toggle(self, frame_width: int, frame_height: int):
        """Toggle recording on/off. Returns the current is_recording state."""
        if self._is_recording:
            self.stop()
        else:
            self.start(frame_width, frame_height)
        return self._is_recording
